export interface LayoutProps {
    children: JSX.Element[] | JSX.Element;
}
