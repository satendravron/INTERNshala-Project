declare namespace IHeading {
    export interface IProps {
        text: string;
    }
}

export { IHeading };
